#include <stdio.h>
int main(void)
{
    // variable declarations

    int ask_i;

    // code
    printf("\n\n");

    printf("Printing Digits 10 to 1 : \n\n");

    for(ask_i = 10; ask_i >= 1; ask_i--)
        printf("\t%d\n", ask_i);

    printf("\n\n");
    return 0;
}