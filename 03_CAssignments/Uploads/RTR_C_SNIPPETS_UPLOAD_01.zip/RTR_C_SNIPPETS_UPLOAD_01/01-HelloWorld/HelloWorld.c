#include<stdio.h>

int main(void)
{
    printf("Helllo World!! \nGreetings from ASK");
    return(0);
}